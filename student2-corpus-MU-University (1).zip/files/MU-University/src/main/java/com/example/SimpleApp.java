package com.example;

public class SimpleApp {
    public static void main(String[] args) {
        System.out.println("Hello, Maven!");
    }

    public int add(int a, int b) {
        return a + b;
    }
}
