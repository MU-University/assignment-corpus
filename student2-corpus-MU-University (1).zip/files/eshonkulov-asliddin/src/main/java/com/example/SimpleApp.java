package com.example;

public class SimpleApp {
    public static void main(String[] args) {
        System.out.println("Hello, Gradle!");
    }

    public int add(int x, int y) {
        return x + y;
    }
}
